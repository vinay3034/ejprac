
import java.sql.*;
import javax.ejb.Stateless;

@Stateless
public class NewSessionBean {

    public NewSessionBean() {
    }
    public String roombook(String rt, String cn, String cm)
    {
    String confirmationMsg="";
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/patkar1","root","root");
            
            PreparedStatement pst = con.prepareStatement("select * from book where RoomType=? and status='Not Booked'");
            pst.setString(1, rt);
            ResultSet rs = pst.executeQuery();
            if(rs.next())
            {
            String rno = rs.getString(1);
            PreparedStatement stm = con.prepareStatement("UPDATE book SET cust=?, mob=?, status='Booked' WHERE roomId=?");
            stm.setString(1, cn);    
            stm.setString(2, cm);    
            stm.setString(3, rno);   
            stm.executeUpdate();
            confirmationMsg = "Room " + rno + " has been reserved <br> The charges applicable for the room is Rs. " + rs.getString(6);
            }
            else
            {
                confirmationMsg="Room "+rt+" is currently not available ...please try again for another room";
            }
        }
        catch(  ClassNotFoundException | SQLException e)
        {
            confirmationMsg=""+e;
        }
        return confirmationMsg;
    } }
