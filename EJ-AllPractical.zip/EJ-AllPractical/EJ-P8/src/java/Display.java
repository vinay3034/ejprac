import javax.ejb.Stateless;

@Stateless
public class Display {
    public Display() {}

    public String Display() {
        return "This is Home Page";
    }
}