
import javax.ejb.Singleton;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Sophia
 */
@Singleton
public class countBean {
private int hit=0;
public countBean(){}
public int verifycount(){
    return hit++;
}

    
}
