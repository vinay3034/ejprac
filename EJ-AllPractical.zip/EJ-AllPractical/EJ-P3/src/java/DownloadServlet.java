/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class DownloadServlet extends HttpServlet {

   @Override
   protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        String filePath = req.getParameter("file");
        File downloadFile = new File(filePath);
        if (!downloadFile.exists()) {
            res.setContentType("text/html");
            res.getWriter().println("<h3>File " + filePath + " not found on the server.</h3>");
            return;
        }
        res.setContentType("application/octet-stream");
        res.setHeader("Content-Disposition", "attachment;filename=\"" + downloadFile.getName() + "\"");
        res.setContentLength((int) downloadFile.length());
        try (FileInputStream inStream = new FileInputStream(downloadFile)) {
         OutputStream outStream = res.getOutputStream();
        byte[] buffer = new byte[4096];
            int bytesRead = -1;
            while ((bytesRead = inStream.read(buffer)) != -1) {
                outStream.write(buffer, 0, bytesRead);
            }
        } catch (IOException e) {
            res.getWriter().println("Error: " + e.getMessage());
         
        }
    }
}
