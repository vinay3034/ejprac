/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Sophia
 */
public class NewServlet extends HttpServlet {
    @EJB
    StudentBean obj;
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
        String msg="";
        String Studname=request.getParameter("SName");
        int mark1=Integer.parseInt(request.getParameter("Sub1"));
        int mark2=Integer.parseInt(request.getParameter("Sub2"));
        int mark3=Integer.parseInt(request.getParameter("Sub3"));
        int totalmarks=mark1+mark2+mark3;
        msg=obj.marksEntry(Studname,mark1,mark2,mark3,totalmarks);
        out.println(msg);
        }
    }
}
