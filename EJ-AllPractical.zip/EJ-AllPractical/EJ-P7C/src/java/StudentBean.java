
import java.sql.*;
import javax.ejb.Stateless;

@Stateless
public class StudentBean {
public StudentBean(){}

public String marksEntry(String name,int mrk1,int mrk2,int mrk3,int total)
{
    String confirmationMsg;
    try
    {
        Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student_records","root","root");
        PreparedStatement ps = con.prepareStatement("insert into student values(?,?,?,?,?)");
        ps.setString(1, name);
        ps.setInt(2, mrk1);
        ps.setInt(3, mrk2);
        ps.setInt(4, mrk3);
        ps.setInt(5, total);
        int r=ps.executeUpdate();
        if(r==1)
        {
            confirmationMsg="<h3><b>" + name + " your marks have been updated successfully<b><h1>";
        }
        else
        {
            confirmationMsg="<h2> Could not update data.Please try Again!!!</h2>";
        }
        
    }
    catch(ClassNotFoundException | SQLException e)
    {
        confirmationMsg=""+e;
    }
    return confirmationMsg;
}
}
